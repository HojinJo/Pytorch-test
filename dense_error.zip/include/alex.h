#ifndef ALEX_H
#define ALEX_H

#include "net.h"
#include "test.h"
#include "thpool.h"

void get_submodule_alexnet(torch::jit::script::Module module, std::vector<torch::jit::Module> &child);
void get_submodule_alex(torch::jit::script::Module module, std::vector<std::function<torch::jit::IValue(std::vector<torch::jit::IValue>)>> &child);
void *predict_alexnet(Net *input);
void forward_alexnet(th_arg *th);

#endif

